import { create } from 'zustand';
import { Client, Lot } from '../types';
import { sampleLots } from '../data/sampleLots';

interface Store {
  clients: Client[];
  lots: Lot[];
  isAdmin: boolean;
  addClient: (client: Client) => void;
  updateLot: (lotId: string, clientId: string) => void;
  setIsAdmin: (value: boolean) => void;
}

export const useStore = create<Store>((set) => ({
  clients: [],
  lots: sampleLots, // Initialize with sample lots
  isAdmin: false,
  addClient: (client) =>
    set((state) => ({ clients: [...state.clients, client] })),
  updateLot: (lotId, clientId) =>
    set((state) => ({
      lots: state.lots.map((lot) =>
        lot.id === lotId
          ? { ...lot, clientId, status: 'sold' as const }
          : lot
      ),
    })),
  setIsAdmin: (value) => set({ isAdmin: value }),
}));