export interface Client {
  id: string;
  name: string;
  cpf: string;
  rg: string;
  birthDate: string;
  maritalStatus: string;
  phone: string;
  referencePhone: string;
  email: string;
  profession: string;
  address: string;
  broker: string;
}

export interface Lot {
  id: string;
  number: string;
  totalArea: string;
  price: number;
  paymentMethod: string;
  clientId?: string;
  status: 'available' | 'sold';
  coordinates: {
    x: number;
    y: number;
  };
}