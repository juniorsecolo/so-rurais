import React from 'react';
import { MapPin, Users, ClipboardList } from 'lucide-react';

export const Home = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="relative h-[500px] bg-cover bg-center" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80")'
      }}>
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">Só Rurais</h1>
            <p className="text-xl">Seu sonho rural começa aqui</p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-lg text-center">
            <MapPin className="mx-auto h-12 w-12 text-green-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Localização Privilegiada</h3>
            <p className="text-gray-600">Lotes estrategicamente posicionados em áreas rurais de alto potencial</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-lg text-center">
            <Users className="mx-auto h-12 w-12 text-green-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Atendimento Personalizado</h3>
            <p className="text-gray-600">Equipe especializada para encontrar o lote ideal para você</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-lg text-center">
            <ClipboardList className="mx-auto h-12 w-12 text-green-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Documentação Facilitada</h3>
            <p className="text-gray-600">Processo simplificado e seguro para sua aquisição</p>
          </div>
        </div>
      </div>
    </div>
  );
};