import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Lot } from '../types';

export const LotMap = () => {
  const { lots, clients, isAdmin } = useStore();
  const [selectedLot, setSelectedLot] = useState<Lot | null>(null);
  const [scale, setScale] = useState(1);

  const handleLotClick = (lot: Lot) => {
    setSelectedLot(lot);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const handleZoomIn = () => {
    setScale(prev => Math.min(prev + 0.2, 2));
  };

  const handleZoomOut = () => {
    setScale(prev => Math.max(prev - 0.2, 0.5));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:w-2/3">
          <div className="mb-4 flex gap-2 justify-end">
            <button
              onClick={handleZoomOut}
              className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
            >
              -
            </button>
            <button
              onClick={handleZoomIn}
              className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
            >
              +
            </button>
          </div>
          <div className="relative w-full h-[800px] bg-[url('https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center border-2 border-gray-300 rounded-lg overflow-auto">
            <div 
              className="absolute inset-0 bg-black bg-opacity-30"
              style={{
                transform: `scale(${scale})`,
                transformOrigin: 'top left',
                width: `${100 / scale}%`,
                height: `${100 / scale}%`
              }}
            >
              {lots.map((lot) => (
                <div
                  key={lot.id}
                  onClick={() => handleLotClick(lot)}
                  style={{
                    position: 'absolute',
                    left: `${lot.coordinates.x}%`,
                    top: `${lot.coordinates.y}%`,
                  }}
                  className={`w-12 h-12 -translate-x-1/2 -translate-y-1/2 cursor-pointer
                    ${lot.status === 'available' ? 'bg-green-500' : 'bg-red-500'}
                    rounded-lg flex items-center justify-center text-white font-bold text-sm
                    hover:scale-110 transition-transform`}
                >
                  {lot.number}
                </div>
              ))}
            </div>
          </div>
          <div className="mt-4 flex gap-4 justify-center">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-500 rounded"></div>
              <span>Disponível</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-500 rounded"></div>
              <span>Vendido</span>
            </div>
          </div>
        </div>

        <div className="lg:w-1/3">
          {selectedLot && (
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-2xl font-bold mb-4">Lote {selectedLot.number}</h3>
              <div className="space-y-3">
                <p><strong>Área Total:</strong> {selectedLot.totalArea}</p>
                <p><strong>Preço:</strong> {formatCurrency(selectedLot.price)}</p>
                <p><strong>Forma de Pagamento:</strong> {selectedLot.paymentMethod}</p>
                <p><strong>Status:</strong> {selectedLot.status === 'available' ? 'Disponível' : 'Vendido'}</p>
                
                {isAdmin && selectedLot.clientId && (
                  <div className="mt-4 pt-4 border-t">
                    <h4 className="text-lg font-semibold mb-2">Informações do Cliente</h4>
                    {clients.map(client => client.id === selectedLot.clientId && (
                      <div key={client.id} className="space-y-2">
                        <p><strong>Nome:</strong> {client.name}</p>
                        <p><strong>Telefone:</strong> {client.phone}</p>
                        <p><strong>Email:</strong> {client.email}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};