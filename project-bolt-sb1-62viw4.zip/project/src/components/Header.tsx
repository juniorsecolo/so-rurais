import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, LogIn } from 'lucide-react';
import { useStore } from '../store/useStore';

export const Header = () => {
  const { isAdmin, setIsAdmin } = useStore();

  const handleLogout = () => {
    setIsAdmin(false);
  };

  return (
    <header className="bg-green-800 text-white">
      <div className="container mx-auto px-4 py-6">
        <nav className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2 text-2xl font-bold">
            <MapPin size={32} />
            <span>Só Rurais</span>
          </Link>
          <div className="space-x-6 flex items-center">
            <Link to="/" className="hover:text-green-200">Início</Link>
            <Link to="/map" className="hover:text-green-200">Mapa de Lotes</Link>
            {isAdmin ? (
              <>
                <Link to="/admin" className="hover:text-green-200">Área Administrativa</Link>
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-1 hover:text-green-200"
                >
                  <span>Sair</span>
                </button>
              </>
            ) : (
              <Link to="/login" className="flex items-center space-x-1 hover:text-green-200">
                <LogIn size={20} />
                <span>Entrar</span>
              </Link>
            )}
          </div>
        </nav>
      </div>
    </header>
  );
};