import { Lot } from '../types';

// Helper function to generate coordinates in a grid layout
const generateCoordinates = (row: number, col: number, totalRows: number, totalCols: number) => {
  const padding = 10; // Padding from edges in percentage
  const availableWidth = 100 - (2 * padding);
  const availableHeight = 100 - (2 * padding);
  
  const x = padding + (availableWidth / (totalCols - 1)) * col;
  const y = padding + (availableHeight / (totalRows - 1)) * row;
  
  return { x, y };
};

// Generate initial lots (1A through 10C)
export const sampleLots: Lot[] = [
  // Row 1
  { id: '1A', number: '1A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(0, 0, 10, 4) },
  { id: '1B', number: '1B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(0, 1, 10, 4) },
  { id: '1C', number: '1C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(0, 2, 10, 4) },
  { id: '1D', number: '1D', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(0, 3, 10, 4) },

  // Row 2
  { id: '2A', number: '2A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(1, 0, 10, 4) },
  { id: '2B', number: '2B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(1, 1, 10, 4) },
  { id: '2C', number: '2C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(1, 2, 10, 4) },
  { id: '2D', number: '2D', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(1, 3, 10, 4) },

  // Row 3
  { id: '3A', number: '3A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(2, 0, 10, 4) },
  { id: '3B', number: '3B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(2, 1, 10, 4) },
  { id: '3C', number: '3C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(2, 2, 10, 4) },
  { id: '3D', number: '3D', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(2, 3, 10, 4) },
  { id: '3E', number: '3E', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(2, 4, 10, 4) },

  // Row 4
  { id: '4A', number: '4A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(3, 0, 10, 4) },
  { id: '4B', number: '4B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(3, 1, 10, 4) },
  { id: '4C', number: '4C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(3, 2, 10, 4) },

  // Row 5
  { id: '5A', number: '5A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(4, 0, 10, 4) },
  { id: '5B', number: '5B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(4, 1, 10, 4) },
  { id: '5C', number: '5C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(4, 2, 10, 4) },

  // Row 6
  { id: '6A', number: '6A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(5, 0, 10, 4) },
  { id: '6B', number: '6B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(5, 1, 10, 4) },
  { id: '6C', number: '6C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(5, 2, 10, 4) },

  // Row 7
  { id: '7A', number: '7A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(6, 0, 10, 4) },
  { id: '7B', number: '7B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(6, 1, 10, 4) },
  { id: '7C', number: '7C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(6, 2, 10, 4) },

  // Row 8
  { id: '8A', number: '8A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(7, 0, 10, 4) },
  { id: '8B', number: '8B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(7, 1, 10, 4) },
  { id: '8C', number: '8C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(7, 2, 10, 4) },

  // Row 9
  { id: '9A', number: '9A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(8, 0, 10, 4) },
  { id: '9B', number: '9B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(8, 1, 10, 4) },
  { id: '9C', number: '9C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(8, 2, 10, 4) },

  // Row 10
  { id: '10A', number: '10A', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(9, 0, 10, 4) },
  { id: '10B', number: '10B', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(9, 1, 10, 4) },
  { id: '10C', number: '10C', totalArea: '1000m²', price: 150000, paymentMethod: 'À definir', status: 'available', coordinates: generateCoordinates(9, 2, 10, 4) },
];